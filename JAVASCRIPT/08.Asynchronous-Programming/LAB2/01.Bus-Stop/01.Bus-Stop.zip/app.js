async function getInfo() {
    const desiredID = document.querySelector("#stopId").value;
    const resultTitle = document.querySelector("#stopName");
    const resultList = document.querySelector("#buses");
    resultList.innerHTML = "";

    try {
        response = await fetch(`http://localhost:3030/jsonstore/bus/businfo/${desiredID}`);
        parsedData = await response.json();

        resultTitle.textContent = parsedData.name
        Object.entries(parsedData.buses).forEach(([busId, time]) => {
            let listItem = document.createElement("li")
            listItem.textContent = `Bus ${busId} arrives in ${time} minutes`
            resultList.appendChild(listItem)
        })
    } catch (_) {
        resultTitle.textContent = "Error"
    }
}





// function getInfo() {
//     const baseUrl = "http://localhost:3030/jsonstore/bus/businfo";
//     const checkButton = getElementByTag("#submit");
//     const stopNameEl = getElementByTag("#stopName");
//     const busesList = getElementByTag("#buses");
//
//     checkButton.addEventListener("click", loadRecords);
//
//     async function loadRecords() {
//         busesList.innerHTML = "";
//         stopNameEl.textContent = "";
//
//         const stopId = getElementByTag("#stopId").value;
//
//         try {
//             const response = await fetch(`${baseUrl}/${stopId}`);
//             if (!response.ok) {
//                 stopNameEl.textContent = "Error";
//             }
//
//             const data = await response.json();
//
//             stopNameEl.textContent = data.name;
//             Object.entries(data.buses).forEach(([busId, time]) => {
//                 const liElement = createEl("li");
//                 liElement.textContent = `Bus ${busId} arrives in ${time} minutes`;
//                 busesList.appendChild(liElement);
//             });
//         } catch (error) {
//             stopNameEl.textContent = "Error";
//         }
//     }
//
//     function getElementByTag(tag) {
//         return document.querySelector(tag);
//     }
//
//     function createEl(el) {
//         return document.createElement(el);
//     }
// }
