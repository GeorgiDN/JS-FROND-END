const apiURL = "http://localhost:3030/jsonstore/advanced/profiles";
const mainContainer = document.querySelector("#main");
let userCounter = 0;

async function lockedProfile() {
    mainContainer.innerHTML = "";
    let profilesData = await ((await fetch(apiURL)).json());
    Object.values(profilesData)
        .map(profile => {
            let profileContainer = createProfileContainer(profile);
            mainContainer.appendChild(profileContainer);
        });
};

function createProfileContainer(profile) {
    userCounter++;
    let profileContainer = document.createElement("div");
    profileContainer.classList.add("profile");

    profileContainer.appendChild(createImageItem());

    profileContainer.innerHTML += `<label>Lock</label>
        <input type = "radio" name = "user${userCounter}Locked" value = "lock" checked />
    <label>Unlock</label>
    <input type="radio" name="user${userCounter}Locked" value="unlock"><br>
    <hr>
    <label>Username</label>
    <input type="text" name="user${userCounter}Username" value="${profile.username}" disabled readonly />`;

    profileContainer.appendChild(createExtraInfoContainer(profile));
    profileContainer.appendChild(createToggleButton());

    return profileContainer
};

function createImageItem() {
    let imgItem = document.createElement("img");
    imgItem.src = "./iconProfile2.png";
    imgItem.classList.add("userIcon");
    return imgItem
};

function createExtraInfoContainer(profile) {
    let extraInfoContainer = document.createElement("div");
    extraInfoContainer.style.display = "none";
    extraInfoContainer.classList.add(`user${userCounter}Username`);
    extraInfoContainer.appendChild(document.createElement("hr"));

    extraInfoContainer.innerHTML += `<label>Email:</label>
    <input type="email" name="user${userCounter}Email" value="${profile.email}" disabled readonly />
    <label>Age:</label>
    <input type="email" name="user${userCounter}Age" value="${profile.age}" disabled readonly />`;

    return extraInfoContainer
};

function createToggleButton() {
    let toggleBtn = document.createElement("button");
    toggleBtn.addEventListener("click", toggleInfo);
    toggleBtn.textContent = "Show more";

    return toggleBtn
};

function toggleInfo(event) {
    let currentBtn = event.target
    let hiddenFields = currentBtn.parentElement.querySelector("div");

    const isHidden = currentBtn.textContent === "Show more";
    const isLocked = checkIfLocked(currentBtn);

    if (!isLocked) {
        currentBtn.textContent = isHidden ? "Hide it" : "Show more";
        hiddenFields.style.display = isHidden ? "block" : "none";
    };
};

function checkIfLocked(button) {
    let lockedStatus = button.parentElement.querySelector("input[value=lock]");
    return lockedStatus.checked
};








// async function lockedProfile() {
//     const baseURL = "http://localhost:3030/jsonstore/advanced/profiles";
//
//     let profilesResponse = await fetch(baseURL);
//     let profiles = await profilesResponse.json();
//
//     let mainElement = document.getElementById("main");
//     mainElement.innerHTML = "";
//
//     let counter = 1;
//     for (let [profileID, profileInfo] of Object.entries(profiles)) {
//         let divProfile = document.createElement("div");
//         divProfile.className = "profile"
//
//         let profileHTML = `
//             <img src="./iconProfile2.png" class="userIcon" />
//             <label>Lock</label>
//             <input type="radio" name="user${counter}Locked" value="lock" checked>
//             <label>Unlock</label>
//             <input type="radio" name="user${counter}Locked" value="unlock"><br>
//             <hr>
//             <label>Username</label>
//             <input type="text" name="user${counter}Username" value="${profileInfo.username}" disabled readonly />
//             <div class="user${counter}HiddenFields">
//                 <hr>
//                 <label>Email:</label>
//                 <input type="email" name="user${counter}Email" value="${profileInfo.email}" disabled readonly />
//                 <label>Age:</label>
//                 <input type="email" name="user${counter}Age" value="${profileInfo.age}" disabled readonly />
//             </div>
//
//             <button>Show more</button>
//         `
//
//         divProfile.innerHTML = profileHTML;
//         divProfile.querySelector("div").style.display = "none";
//         mainElement.appendChild(divProfile);
//
//         let showMoreButton = divProfile.querySelector("button");
//         showMoreButton.addEventListener("click", moreInfoEvent);
//
//         function moreInfoEvent(event) {
//             let lockRadioButton = divProfile.querySelector("input[type='radio']")
//
//             if (showMoreButton.textContent === "Show more" && !lockRadioButton.checked) {
//                 divProfile.querySelector("div").style.display = "block"
//                 showMoreButton.textContent = "Hide it"
//             } else if (showMoreButton.textContent === "Hide it" && !lockRadioButton.checked) {
//                 divProfile.querySelector("div").style.display = "none"
//                 showMoreButton.textContent = "Show more"
//             }
//         }
//
//         counter += 1
//     }
// }
